import Banner from '@/components/Banner'
import React from 'react'

const index = () => {
  return (
    <div>
        <Banner 
        title='Simplifying Your Life with Innovative Solutions'
        description='Eurosia is a cutting-edge app development company that specializes in building top-of-the-line mobile and web applications for businesses of all sizes. Our team of experienced developers, designers, and project managers work together to provide custom solutions that meet the unique needs of each client.'
       leftImage='/images/Banner/banner.png'
         />
      
    </div>
  )
}

export default index