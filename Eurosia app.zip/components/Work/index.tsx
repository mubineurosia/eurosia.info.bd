import Image from 'next/image';

interface workdata {
    imgSrc: string;
    heading: string;
    subheading: string;
    hiddenpara: string;
}

const workdata: workdata[] = [
    {
        imgSrc: '/images/Work/icon-three.svg',
        heading: 'Software Development',
        subheading: 'We specialize in developing robust and scalable software solutions that meet the unique needs of businesses.',
        hiddenpara: 'We offer reliable and responsive IT support services that help businesses keep their systems up and running smoothly.',
    },
    {
        imgSrc: '/images/Work/icon-one.svg',
        heading: 'Mobile App Development',
        subheading: 'We develop cutting-edge mobile apps for iOS and Android that are user-friendly and highly functional.',
        hiddenpara: 'We develop cutting-edge mobile apps for iOS and Android that are user-friendly and highly functional.',
    },
    {
        imgSrc: '/images/Work/icon-two.svg',
        heading: 'Web Development',
        subheading: 'Our team of developers creates custom websites and web applications that are tailored to your specific business needs.',
        hiddenpara: 'Our team of developers creates custom websites and web applications that are tailored to your specific business needs.',
    },
    {
        imgSrc: '/images/Work/icon-three.svg',
        heading: 'E-commerce Solutions',
        subheading: 'We develop e-commerce solutions that help you sell your products and services online, while providing a seamless user experience',
        hiddenpara: 'We develop e-commerce solutions that help you sell your products and services online, while providing a seamless user experience...',
    },
    {
        imgSrc: '/images/Work/icon-three.svg',
        heading: 'Digital Marketing ',
        subheading: 'We help businesses improve their online presence and reach their target audience through effective digital marketing strategies',
        hiddenpara: 'We help businesses improve their online presence and reach their target audience through effective digital marketing strategies',
    },
    {
        imgSrc: '/images/Work/icon-three.svg',
        heading: 'IT Consulting',
        subheading: 'We offer expert IT consulting services that help businesses optimize their technology investments and achieve their business objectives.',
        hiddenpara: 'We offer expert IT consulting services that help businesses optimize their technology investments and achieve their business objectives.',
    },


]

const Work = () => {
    return (
        <div>
            <div className='mx-auto max-w-7xl mt-16 px-6 mb-20 relative'>
                <div className="radial-bgone hidden lg:block"></div>
                <div className='text-center mb-14'>
                    <h3 className='text-offwhite text-3xl md:text-5xl font-bold mb-3'>How it work</h3>
                    <p className='text-bluish md:text-lg font-normal leading-8'>Our IT company specializes in helping businesses optimize their technology infrastructure. We provide IT consulting, infrastructure design and implementation, software development, and ongoing IT support. Contact us to learn how we can help your business streamline its operations and reduce costs.</p>
                </div>

                <div className='grid md:grid-cols-2 lg:grid-cols-3 gap-y-20 gap-x-5 mt-32'>

                    {workdata.map((items, i) => (
                        <div className='card-b p-8' key={i}>
                            <div className='work-img-bg rounded-full flex justify-center absolute p-6'>
                                <Image src={items.imgSrc} alt={items.imgSrc} width={44} height={44} />
                            </div>
                            <div>
                                <Image src={'/images/Work/bg-arrow.svg'} alt="arrow-bg" width={85} height={35} />
                            </div>
                            <h3 className='text-2xl text-offwhite font-semibold text-center mt-8'>{items.heading}</h3>
                            <p className='text-base font-normal text-bluish text-center mt-2'>{items.subheading}</p>
                            {/* <span className="text-base font-normal m-0 text-bluish text-center hides">{items.hiddenpara}</span> */}
                        </div>
                    ))}

                </div>

            </div>
        </div>
    )
}

export default Work;
